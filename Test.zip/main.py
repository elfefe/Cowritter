import asyncio
from kdp.main_orchestrator import Orchestrator
import os

async def main():
    orch = Orchestrator(backend=os.environ.get('KDP_BACKEND','openai'))
    await orch.run()

if __name__ == '__main__':
    asyncio.run(main())