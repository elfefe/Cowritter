# Blueprint — Autonomous Agentic Pipeline to Write Nonfiction Books

**Goal:** build an agentic system that discovers ultra‑specific nonfiction book ideas, drafts a full 10k–20k word manuscript, iterates with specialized reviewers, and outputs a final human‑quality manuscript. The pipeline should be modular so each role can be its own agent (or microservice), allow for automated quality checks, and include human‑in‑the‑loop gates where appropriate.

---

## 1) High-level architecture

**Components:**

* **Orchestrator (Controller)** — the central coordinator that runs the pipeline, assigns work, enforces retries/loops, and stores state.
* **Agent Pool** — specialized agents (Idea, Research, Title, Outline, Drafting, Expansion, Style/Tone, Repetition Detector, Fact-checker, Editor, Assembler, QA, (optional) Publishing Prep).
* **State Store** — versioned storage for outlines, drafts, agent outputs, prompts, and metadata (e.g., S3 + DynamoDB / Postgres / Git LFS for large files).
* **Prompt/Template Store** — a repo of canonical prompts, few‑shot examples, style guides, and instruction tokens.
* **Evaluation & Metrics Engine** — automated tests, heuristics, and scoring to evaluate fluency, novelty, tone, repetitiveness, and alignment with the outline.
* **Human Review UI** — lightweight interface for inspection, corrections, and accept/ reject decisions (also supports annotated feedback that agents can consume).
* **Monitoring & Logging** — telemetry for costs, latency, failure rates, and quality drift.

Flow: Idea Agent → Research Agent → Title Agent → Outline Agent → Parallel Chapter Drafting Agents → Expansion Agent → Style/Tone Agent → Repetition & Quality Agents → Fact-checker → Editor Agent → Assembler → Final QA → (optional) Publishing Prep.

---

## 2) Design principles & constraints

* **Modularity:** each responsibility is its own agent. Swap or improve agents without rewriting the pipeline.
* **Iterative, not one‑shot:** allow N review cycles with thresholds for auto‑accept and fallbacks to human review.
* **Stateful context:** store style guides, tone anchors, and a canonical outline to keep writing consistent.
* **Detect & prevent robotic output:** use a human‑like variation rubric and a second model review.
* **Cost vs. quality tradeoffs:** use smaller models for research/QA heuristics, larger models for final drafts and heavy editing passes.
* **Safety & publishing legal checks:** ensure no disallowed content, no medical/legal advice beyond disclaimers. If the domain is medical/financial/legal, add human expert review gates.

---

## 3) Agent roster and responsibilities

Below are recommended agents. Each agent is an LLM-backed service with a specific prompt template and evaluation checklist.

### 3.1 Idea Agent

**Purpose:** find ultra‑specific, low‑competition niches and output 5–10 candidate ideas with search intent phrasing.
**Inputs:** topic categories, user constraints (word count, tone), and optional seed phrases.
**Outputs:** list of candidates with metadata: working title (long‑tail), subtitle, 3 supporting keyword phrases, target audience, and a 1‑sentence pitch.
**Heuristics:** avoid broad topics. Prefer "\[Who] + \[situation] + \[outcome]" patterns (e.g., "New Dads Managing Night Feeding for Breastfeeding Partners").

**Prompt snippet:**

```
You are an idea discovery agent. Based on the categories: parenting, health, learning, self-improvement, caregiving, produce 8 ultra-specific book ideas.
For each idea return: title, subtitle, 3 long-tail keyword search phrases, target reader persona, one-sentence pitch, and why it's low-competition (brief). Keep each title ≤ 10 words and subtitle ≤ 12 words.
```

---

### 3.2 Research Agent

**Purpose:** compile factual, evergreen details and practical steps for the chosen topic. Produce raw notes, lists, stats, common questions (FAQ), and credible sources to cite (human must verify links if used).
**Inputs:** selected idea from Idea Agent.
**Outputs:** research file (bulleted notes per chapter), a 10–15 question FAQ, and a short bibliography candidate list.
**Safety:** flag any medical/legal claims and add a human‑expert required flag.

**Prompt snippet:**

```
You are a research assistant for a book titled: <TITLE>. Produce: topic scope, 10–12 subtopics for chapters, 30 practical tips, 10 real-life example prompts (short scenarios), and 10 common questions readers ask online.
Mark all statements that could require source verification or expert review.
```

---

### 3.3 Title & Positioning Agent

**Purpose:** finalize a SEO‑friendly title + subtitle and 7 metadata keywords optimized for long-tail Amazon searches.
**Inputs:** idea + research outputs + target persona.
**Outputs:** final title, subtitle, 7 KDP keywords, 3 subtitle variations, 1 short back-cover blurb (3–4 sentences), and the book promise.

**Prompt snippet:**

```
Given the idea and research notes, propose 3 final title+subtitle pairs optimized for long-tail search. For each, give 7 keywords/phrases for Amazon KDP metadata and a 40–60 word back-cover blurb.
```

---

### 3.4 Outline Agent

**Purpose:** create a chapter-by-chapter outline, with goals, word targets per chapter, and chapter-level acceptance criteria.
**Inputs:** title/subtitle, research file, desired total word count.
**Outputs:** ordered chapter list, 3–6 bullet subheadings per chapter, target word counts, and a list of must-cover items (minimally one actionable checklist or example per chapter).

**Prompt snippet:**

```
Create a detailed outline for a ~15,000-word guide titled <TITLE>. Produce 10-14 chapters. For each chapter provide: 3-6 subheadings, a 300-word chapter goal description, and 3 examples or a checklist that must appear.
```

---

### 3.5 Chapter Drafting Agent (parallelizable)

**Purpose:** produce first drafts for chapters following the outline and tone guide.
**Inputs:** chapter spec, style guide, chapter context (previous/next chapter summaries), and up to 2 example paragraphs of tone.
**Outputs:** 1st draft for the chapter (target words ±10%).
**Behavior:** run in parallel for multiple chapters but ensure each uses the canonical style guide and references previous chapters' context so flow remains coherent.

**Prompt snippet:**

```
Write Chapter X: [chapter title]. Tone: friendly, conversational, practical. Use varied sentence lengths and first-person plural occasionally. Include 2 short real-world examples and 1 checklist. Do not repeat content from other chapters; reference them when needed.
```

---

### 3.6 Expansion & Depth Agent

**Purpose:** ensure chapters reach depth & word targets, add examples, add transitions, and expand skimpy parts.
**Inputs:** first draft, chapter goals, research notes.
**Outputs:** expanded draft, annotated with where new examples or citations were inserted.
**Heuristics:** use the research notes to add 2–4 actionable steps per chapter and a short anecdote / example.

---

### 3.7 Style & Human‑Voice Agent

**Purpose:** convert text into a naturally flowing, human-sounding voice. Add rhetorical variety, fix flatness, and insure readability.
**Inputs:** expanded draft and style guide.
**Outputs:** rewritten draft with an explanation of major style edits and a style-score.
**Evaluation:** measure sentence length variance, filler words, passive vs active ratio, and vocabulary variety.

**Prompt snippet:**

```
Rewrite the following text to sound like a caring, experienced friend teaching practical steps. Vary sentence beginnings, add 1 short anecdote where relevant, replace passive voice with active where stronger, and ensure readability at 8-10th grade level.
```

---

### 3.8 Repetition / Boredom Detector Agent

**Purpose:** detect repeated facts, redundant phrasing, and sections likely to bore readers.
**Inputs:** current manuscript, outline.
**Outputs:** list of flagged passages, suggested consolidations, and recommended areas to replace with an anecdote, example, or exercise.
**Metrics:** semantic similarity detection across chapters, N‑gram overlap rates, and novelty scoring.

---

### 3.9 Fact-checker Agent

**Purpose:** identify empirical claims, numbers, and technical advice. Tag anything needing a citation or expert review.
**Inputs:** manuscript and research notes.
**Outputs:** list of claims with suggested verification steps, severity levels (low/medium/high), and whether a human expert is required.
**Behavior:** do not attempt web verification unless the Research Agent included sources. This agent flags claims and suggests what type of source to consult (academic, official guidelines, expert interview).

---

### 3.10 Editor Agent (copy+structural)

**Purpose:** perform copy editing (grammar, punctuation), structural edits (flow, transitions), and polish headings. This is the last automated editing pass before human QA.
**Inputs:** manuscript, style guide, list of flagged items from Repetition and Fact-checker.
**Outputs:** near-final manuscript and a summary of edits.

---

### 3.11 Assembler & Formatter Agent

**Purpose:** merge chapters, ensure consistent formatting, generate a clean plain-text manuscript with headings, and produce a TOC stub.
**Inputs:** final chapters, front/back matter instructions.
**Outputs:** single manuscript file (Markdown / .docx) and a manifest of chapters with versions.

---

### 3.12 QA Agent (Acceptance Tests)

**Purpose:** run automated checks and produce an acceptance score. If score ≥ threshold, mark ready for human review or auto‑finalize depending on settings.
**Checks include:**

* Word count in range
* All chapter goals met
* Tone score within target
* Repetition below threshold
* All high‑severity fact flags resolved
* Readability at target grade-level
* No disallowed content

**Outputs:** detailed QA report with pass/fail on each metric.

---

### 3.13 Publishing Prep Agent (optional)

**Purpose:** prepare metadata, back-cover copy, suggested categories, keyword sets, and a simple cover brief for a designer.
**Inputs:** final manuscript and title metadata.
**Outputs:** KDP-ready metadata file and a cover design brief.

---

## 4) Orchestration logic & iterations

**Controller responsibilities:**

* Launch agents in order, provide them required context and past state.
* Support parallel chapter drafting while enforcing global consistency.
* Implement retry policies and bounded iteration loops: e.g., `max_drafts=3` for each chapter before escalating to human review.
* Maintain versioning: every agent output is saved as a new version commit.
* Implement gating rules: e.g., if `QA_score < 0.7` or `high_severity_fact_flags > 0`, send to human review.

**Example orchestration pseudocode:**

```python
# simplified controller loop
idea = IdeaAgent.run(seed_categories)
research = ResearchAgent.run(idea)
title = TitleAgent.run(idea, research)
outline = OutlineAgent.run(title, research, word_target=15000)
# parallel chapter drafts
chapters = Parallel.map(outline.chapters, lambda ch: DraftAgent.run(ch))
chapters = map(ExpansionAgent, chapters)
chapters = map(StyleAgent, chapters)
# repetition & fact-check
flags = RepetitionAgent.run(chapters)
fact_flags = FactChecker.run(chapters)
# if flags unresolved and retries exhausted -> human review
if severe_issues(flags, fact_flags):
    escalate_to_human(chapters, flags, fact_flags)
else:
    final = Assembler.run(chapters)
    qa = QAAgent.run(final)
    if qa.score >= threshold: publish_prep = PublishingAgent.run(final)
```

**Iteration rules:**

* Each chapter runs up to 3 automated edit cycles (Draft → Expand → Style → Repetition fix). If still failing metrics, it goes to human revision.
* Global consistency passes (Style + Terminology + Voice) happen after all chapters reach their draft target.

---

## 5) Prompts, few-shot examples & style guide (practical)

### Global style guide (canonical)

* Tone: friendly, conversational, helpful. Use second person lightly and first-person plural when empathic ("we").
* Length: short paragraphs (2–5 sentences). Use headings and bullet lists liberally.
* Readability: aim for 8–10th grade level.
* Voice features: occasional rhetorical question, varied sentence lengths, small anecdotes.
* Avoid: excessive filler, repetitive sentence openings, clinical or overly formal language.

### Sample prompt: Chapter Draft Agent (few-shot)

```
You are an experienced, friendly nonfiction author. Write a 1400-word chapter from this outline:
- Chapter title: [title]
- Goal: [300-word goal]
- Subheadings: [list]
Tone: friendly, practical, conversational. Include: 2 short real-life examples, one 6-step checklist, 3 actionable tips. Avoid repeating content from previous chapters; if referencing earlier material, include a forward pointer.

Example paragraph (tone reference):
"When I first started, I thought the whole process would be straightforward. But like many of you, I learned by doing — and by making a few mistakes. That’s okay. Let’s walk through the easy, practical steps that actually made a difference for me."
```

### Sample prompt: Repetition Detector

```
Analyze the manuscript for repeated facts, phrases, and themes. Return a list of passages with semantic similarity > 0.75 to earlier passages, grouped by cluster, and suggested edits (remove, consolidate, or replace with anecdote). Include an overall repetition score 0-1.
```

### Style scoring rubric (used by Style Agent)

* Sentence variety: target stddev of sentence length > X
* Passive voice: < 10% sentences
* Filler rate ("very", "really", "actually"): < 2% words
* Anecdote ratio: >= 1 anecdote per chapter

---

## 6) Evaluation metrics & acceptance thresholds

**Key metrics:**

* **Tone Score (0–1):** similarity to tone exemplars using embedding cosine distance.
* **Repetition Score (0–1):** higher is worse; target < 0.15.
* **Fact Severity Count:** integer count of high/medium/low flags.
* **Readability Grade:** Flesch‑Kincaid grade target 8–10.
* **Chapter Goal Coverage:** percent of chapter goals matched by presence of must-cover items.
* **Novelty:** % of unique semantic content per chapter vs. rest of manuscript.

**Acceptance rule:** manuscript passes automated QA if:

* total\_word\_count in range
* Tone Score ≥ 0.75
* Repetition Score ≤ 0.15
* All high severity facts cleared
* Average chapter goal coverage ≥ 90%

If the manuscript fails any of the above, the orchestrator triggers the relevant agent(s) for targeted rewrites.

---

## 7) Human-in-the-loop & escalation policies

**When to require a human review:**

* Any high‑severity fact flag.
* `QA_score < 0.6` after automated attempts.
* Repeated failed cycles for the same chapter (>3 retries).
* Topics with legal or medical implications.

**Human feedback ingestion:**

* UI returns line‑level comments; these are converted into structured edit tasks (e.g., transform into prompts for ChapterDraftingAgent or EditorAgent to re-run a focused rewrite).

---

## 8) Data model & versioning

**Entities:** `Project`, `Idea`, `ResearchNotes`, `Outline`, `ChapterDraft[v]`, `AgentRunLog`, `QAReport`, `FinalManuscript`.

**Versioning:** commit each agent output as `chapter_X_vN` with metadata: `agent`, `timestamp`, `prompt_hash`, `model_name`, `tokens_used`, `parent_version`.

**Storage suggestions:**

* Use object storage for drafts (S3), relational DB for structure & metadata, and ElasticSearch for full-text search & similarity queries.

---

## 9) Deployment, scaling & cost considerations

**Model tuning:**

* Use smaller cheaper models for routine analysis (Repetition Detector, Research summarization) and larger higher‑quality models for draft generation and heavy style rewrites.
* Example split: GPT‑4‑equivalent for drafting & style, GPT‑3.5‑equivalent for research/summaries.

**Parallelism:** draft chapters concurrently to save time, but run global style pass after all chapters finish.

**Cost controls:**

* Limit retries and do narrow focused rewrites rather than full-regenerations.
* Cache model outputs and embeddings for repeated checks.

---

## 10) Safety, legal & ethical checks

* **Medical/legal content:** mark as requiring expert human review and add a clear disclaimer in manuscript.
* **Copyright & hallucination risk:** avoid producing verbatim copyrighted content. Fact‑checker flags claims that need sources. Use paraphrasing and original examples.
* **Privacy:** never invent real identifiable case studies without consent.
* **Plagiarism check:** run a similarity check (embeddings/full-text) before finalizing.

---

## 11) Example mini-run (walkthrough)

**Seed:** parenting → user chooses: C‑section recovery for first‑time moms.

1. Idea Agent returns candidate: "First‑Time Mom Guide to C‑Section Recovery" with keywords.
2. Research Agent produces chapters: pain management, wound care, breastfeeding after C‑section, emotional recovery, practical mobility tips, sleeping with baby when recovering, asking for help, common FAQs.
3. Title Agent finalizes subtitle and KDP keywords.
4. Outline Agent creates 12 chapters, target 14,000 words.
5. Draft Agent runs 3 chapters in parallel; each draft \~1200–1500 words.
6. Expansion & Style Agents refine. Repetition Agent flags two overlapping chapters — controller requests consolidation.
7. Fact‑checker flags 3 medical claims → HUMAN EXPERT gate triggered.
8. After expert clears/annotates, Editor & QA Agents finalize manuscript.

Result: actionable, friendly, medically vetted guide (human sign-off required before publishing).

---

## 12) Implementation roadmap & milestones

**Phase 0 — Prototype (1–3 weeks):**

* Implement Orchestrator skeleton.
* Build Idea, Outline, Draft agents with simple prompts.
* Single-chapter end-to-end demo (generate chapter + style pass + QA).

**Phase 1 — Expand (2–6 weeks):**

* Add parallel drafting, Repetition detector, Fact-flagging.
* Build versioned storage and a minimal Human Review UI.
* Iterate on style rubric and scoring.

**Phase 2 — Harden (4–8 weeks):**

* Add publishing prep, copy editing agent, automated plagiarism checks, and production monitoring.
* Introduce cost optimizations and dynamic model selection.

**Phase 3 — Scale & Automate (ongoing):**

* Connect automated discovery pipelines (trend scraping).
* Add A/B testing for titles & blurbs.
* Automate scheduled runs to produce new low‑competition titles.

---

## Appendix: sample JSON message specs

**AgentRun (example):**

```json
{
  "agent": "ChapterDraftAgent",
  "project_id": "proj_abc123",
  "chapter_id": "ch03",
  "input": {"outline": "...", "tone_ref": "..."},
  "model": "gpt-4-x",
  "prompt_hash": "sha256...",
  "output_id": "ch03_v1"
}
```

**QAReport (example):**

```json
{
  "project_id":"proj_abc123",
  "word_count":14320,
  "tone_score":0.82,
  "repetition_score":0.09,
  "high_severity_flags":0,
  "chapter_coverage": 0.93,
  "pass": true
}
```

---

### Final notes

This blueprint is intentionally detailed so you can map each role to either a microservice, a containerized worker, or a specific prompt+LLM pair. Start small: get the Idea→Outline→Single chapter Draft→Style→QA loop working first. Then add parallelization, automated checks, and human gates.

If you want, I can now:

* generate full example prompts for each agent (copy‑paste ready),
* produce a sample LangChain/Autogen orchestration script, or
* design a minimal database schema and UI wireframe for the human review tool.

Which of these next steps would you like me to deliver right now?

---

## 13) Copy‑paste prompts for each agent (ready to use)

Below are polished prompt templates you can drop into an agent implementation. Replace angle‑bracket placeholders with project-specific text. Keep a canonical `system` instruction across agents like: "You are a professional non‑fiction writer and editor. Be concise, helpful and follow the style guide."

### Idea Agent

```
SYSTEM: You are an idea discovery agent for ultra-specific nonfiction books. Use the categories: parenting, health, learning, self-improvement, caregiving.
USER: Generate 10 candidate book ideas optimized for long-tail Amazon KDP search. For each candidate return a JSON object:
{
  "title": "",
  "subtitle": "",
  "keywords": ["", "", ""],
  "target_persona": "",
  "one_sentence_pitch": "",
  "why_low_competition": ""
}
Do NOT repeat ideas. Keep titles ≤ 10 words. Respond only in JSON.
```

### Research Agent

```
SYSTEM: You are a rigorous research assistant summarizing public knowledge into notes.
USER: Given the selected idea: "<TITLE>", produce:
- 12 chapter-level subtopics (bulleted)
- 30 concise practical tips (bulleted)
- 10 FAQs readers search online (question-only list)
- 10 short example scenarios (1-2 sentences each) usable as anecdotes
- Flag any claim that may require medical/legal expert review (include label: "expert_needed").
Format the output as JSON with fields: subtopics, tips, faqs, examples, flags.
```

### Title & Positioning Agent

```
SYSTEM: You are a marketing copywriter optimizing titles for discoverability.
USER: From research notes produce 3 final title+subtitle options for KDP. For each option include:
- title
- subtitle
- 7 keyword phrases
- 40-60 word back-cover blurb
- one-line rationale for why it will rank for long-tail searches
Return JSON.
```

### Outline Agent

```
SYSTEM: You are an outline specialist.
USER: Create a detailed chapter-by-chapter outline for: "<TITLE>" with target_total_words=<N>. Produce 10-14 chapters. For each chapter include:
- chapter_number
- chapter_title
- 3-6 subheadings
- 300-word chapter_goal
- target_word_count
- 3 must-cover items (examples/checklist)
Return JSON array of chapters.
```

### Chapter Drafting Agent

```
SYSTEM: You are an experienced, friendly nonfiction author.
USER: Write the full draft for Chapter <NUM> from this spec (JSON containing title, goal, subheadings, examples). Tone: friendly, conversational, practical. Length: <target_words> ±10%. Include:
- 2 short real-life examples (use sample placeholders if needed)
- 1 checklist of actionable steps
- natural paragraphing and varied sentence length
Avoid repeating earlier chapter text; if referencing previous content add a short pointer.
Return plain text markdown for the chapter only.
```

### Expansion Agent

```
SYSTEM: You are a content amplifier. Improve depth and add practical steps.
USER: Given: [chapter_draft] and [research_notes], do the following:
1. Identify skimpy sections (<100 words or weak claims).
2. Add 3 concrete actions or a 6-step checklist tied to research notes.
3. Insert one brief anecdote or example.
4. Mark added material with HTML comments <!-- added --> so editors know what changed.
Return enhanced markdown.
```

### Style & Human-Voice Agent

```
SYSTEM: You are a humanizing editor. Use the canonical style guide.
USER: Rewrite the [chapter_text] to ensure:
- friendly voice, natural cadence, sentence variation
- minimal filler words, mostly active voice
- 1 anecdote if none present
- target reading grade 8-10
Also produce a short "style_changes" JSON listing primary edits made.
Return both JSON and rewritten markdown.
```

### Repetition Detector Agent

```
SYSTEM: You are a semantic duplication detector.
USER: Analyze the manuscript and flag passages with semantic similarity > 0.75 to earlier passages. Return JSON with clusters: {cluster_id: {occurrences: [{chapter,loc_snippet}], severity: "low|med|high", suggestion: "consolidate|replace|remove"}} and a repetition_score 0-1.
```

### Fact-Checker Agent

```
SYSTEM: You are a fact-flagging assistant.
USER: Given the manuscript, produce a list of empirical claims with location references. For each claim provide: claim_text, chapter, severity (low/med/high), suggested_source_type (academic/guideline/primary-source), and recommended action (citation_needed|human_review|ok).
Return JSON.
```

### Editor Agent

```
SYSTEM: You are a professional copy and structural editor.
USER: Edit the manuscript for grammar, clarity, transitions and tone consistency. Apply the following constraints: do not change factual claims; note any factual corrections needed as comments. Return edited markdown and a compact change_log JSON.
```

### Assembler Agent

```
SYSTEM: You are a document assembler.
USER: Merge all chapters preserving headings and generate:
- Final single markdown manuscript
- Table-of-contents stub with chapter numbers and titles
- manifest.json listing chapter versions and agent metadata
Return the files as a JSON wrapper with file_contents base64-encoded if needed.
```

### QA Agent

```
SYSTEM: You are an automated QA engine.
USER: Given the final manuscript and acceptance thresholds, compute: word_count, tone_score, repetition_score, high_severity_fact_flags_count, average_chapter_coverage. Return a QA report JSON and pass/fail verdict.
```

### Publishing Prep Agent

```
SYSTEM: You are a publishing prep assistant.
USER: Create KDP metadata including: final_title, subtitle, 7 keywords, 3 suggested categories, 150-200 word book_description, 50-word author_bio, and a one-paragraph cover brief describing imagery and typography recommendations. Return JSON.
```

---

## 14) Example orchestration script (LangChain-like pseudocode & real Python skeleton)

> Note: adapt API calls to your tooling (LangChain, Autogen, or custom orchestrator). This is an executable-style skeleton for clarity; replace `LLM.call()` with your provider's SDK.

```python
# orchestrator.py -- simplified example
from concurrent.futures import ThreadPoolExecutor
import json

# placeholder LLM call
def llm_call(prompt, model="gpt-4"): 
    # integrate your LLM SDK here
    raise NotImplementedError

class Orchestrator:
    def __init__(self, project_id, model_map):
        self.project_id = project_id
        self.model_map = model_map
        self.state = {}

    def run_idea(self, categories):
        prompt = open('prompts/idea_prompt.txt').read().replace('<CATEGORIES>', ','.join(categories))
        out = llm_call(prompt, model=self.model_map['idea'])
        ideas = json.loads(out)
        self.state['ideas'] = ideas
        return ideas

    def run_research(self, idea):
        prompt = open('prompts/research_prompt.txt').read().replace('<TITLE>', idea['title'])
        out = llm_call(prompt, model=self.model_map['research'])
        research = json.loads(out)
        self.state['research'] = research
        return research

    def run_outline(self, title, target_words=15000):
        prompt = open('prompts/outline_prompt.txt').read()
        prompt = prompt.replace('<TITLE>', title).replace('<N>', str(target_words))
        out = llm_call(prompt, model=self.model_map['outline'])
        chapters = json.loads(out)
        self.state['outline'] = chapters
        return chapters

    def draft_chapters_parallel(self, chapters):
        results = {}
        with ThreadPoolExecutor(max_workers=4) as ex:
            futures = {ex.submit(self.draft_single, ch): ch['chapter_number'] for ch in chapters}
            for fut in futures:
                chnum = futures[fut]
                results[chnum] = fut.result()
        self.state['drafts'] = results
        return results

    def draft_single(self, chapter_spec):
        prompt = open('prompts/draft_prompt.txt').read().replace('<CHAPTER_SPEC>', json.dumps(chapter_spec))
        out = llm_call(prompt, model=self.model_map['draft'])
        return out

    # Post-processing, expansion, style, repetition, and QA follow similar patterns.

if __name__ == '__main__':
    models = {
        'idea': 'gpt-3.5', 'research': 'gpt-3.5', 'outline': 'gpt-4',
        'draft': 'gpt-4', 'style': 'gpt-4', 'qa': 'gpt-3.5'
    }
    orch = Orchestrator('proj-demo', models)
    ideas = orch.run_idea(['parenting','health'])
    chosen = ideas[0]
    research = orch.run_research(chosen)
    outline = orch.run_outline(chosen['title'])
    drafts = orch.draft_chapters_parallel(outline)
    # continue with expansion/style/qa
```

**Notes:**

* Use thread/process pools for parallel chapter drafting.
* Persist intermediate outputs after each agent run.
* Integrate a message queue (RabbitMQ / Redis Streams) for robust retry and backoff.

---

## 15) Minimal database schema (Postgres) and sample queries

### Tables (DDL skeleton)

```sql
CREATE TABLE projects (
  project_id TEXT PRIMARY KEY,
  title TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE ideas (
  idea_id SERIAL PRIMARY KEY,
  project_id TEXT REFERENCES projects(project_id),
  title TEXT,
  subtitle TEXT,
  metadata JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE outlines (
  outline_id SERIAL PRIMARY KEY,
  project_id TEXT,
  outline_json JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chapter_versions (
  id SERIAL PRIMARY KEY,
  project_id TEXT,
  chapter_number INT,
  version INT,
  agent TEXT,
  model TEXT,
  content TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE agent_runs (
  id SERIAL PRIMARY KEY,
  project_id TEXT,
  agent TEXT,
  input JSONB,
  output JSONB,
  status TEXT,
  started_at TIMESTAMP,
  finished_at TIMESTAMP
);

CREATE TABLE qa_reports (
  id SERIAL PRIMARY KEY,
  project_id TEXT,
  report_json JSONB,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### Useful query examples

```sql
-- Get latest version of chapter 3
SELECT * FROM chapter_versions
WHERE project_id='proj_123' AND chapter_number=3
ORDER BY version DESC LIMIT 1;

-- Get failed agent runs for project
SELECT * FROM agent_runs WHERE project_id='proj_123' AND status='failed' ORDER BY started_at DESC;
```

---

## 16) Human Review UI wireframe & API endpoints

### UI pages (minimal MVP)

1. **Project Dashboard**

   * Project list, status, word count, QA pass/fail.
2. **Outline Viewer**

   * Display chapter list; buttons: "Generate Draft", "Edit Outline"
3. **Chapter Editor / Diff Viewer**

   * Show current draft, previous versions, highlighted additions (<!-- added -->), inline comments, accept/reject suggestions. Provide quick prompts: "Regenerate paragraph", "Expand example", "Shorten repetition".
4. **QA Console**

   * Show QA report, repetition clusters with preview, fact flags with severity and recommended actions.
5. **Human Sign-off**

   * Final approval screen to mark project ready for publishing.

### Key API endpoints (REST)

* `POST /projects` → create project
* `GET /projects/:id` → project overview
* `POST /projects/:id/agents/:agent_name/run` → kick off agent
* `GET /projects/:id/chapters/:num` → fetch chapter latest
* `POST /projects/:id/chapters/:num/comment` → add human comment
* `POST /projects/:id/qa/approve` → human approve

---

## 17) Testing, monitoring & observability plan

**Unit & integration tests:**

* Mock LLM responses for each agent and test orchestrator flows.
* Test failure scenarios: long-running jobs, API timeouts, and agent retries.

**End‑to‑end tests:**

* Full pipeline run on a trivial topic with assertions: final word count, QA pass, and no high severity flags.

**Monitoring & alerts:**

* Track metrics: agent run time, tokens per run, cost per project, failure rates.
* Set alerts for: high failure rate, spikes in token usage, repeated QA fails.

**Logs & tracing:**

* Correlate `agent_run.id` across services with tracing (OpenTelemetry). Keep prompts and response hashes for audit.

---

## 18) Cost & model selection guidance

**Tiered model approach:**

* Cheap / fast (gpt‑3.5‑equiv): Idea, Research, Repetition detection, QA heuristics.
* Mid tier (gpt‑4‑equiv): Drafting, Expansion.
* High quality / final pass (gpt‑4‑equiv with longer context or tuned model): Style & final editing.

**Cost strategies:**

* Use embeddings + caching for repetition detection instead of repeated LLM calls.
* Use smaller models for iterative passes; only use the expensive model for the final rewrite.
* Batch multiple chapters in a single request where possible to save overhead.

Rough back-of-envelope (project-level) for one 15k-word book (as of typical 2024 prices):

* Research & outlines on 3.5: low
* Drafting 12k–15k words on 4: medium-high
* Editing passes on 4: medium
  Expect a few hundred USD per book in LLM costs depending on model pricing and number of rewrite cycles. Tune retries & cycles to control cost.

---

## 19) Safety, legal & expert review integration (practical)

* Tag any topic with "medical" or "legal" in Idea/Research stage. These projects automatically require an "expert\_review" boolean.
* Expert review flow: export claims and sections needing verification to a PDF or request packet for a human reviewer. Include timestamps, exact quoteable text, and suggested source types.
* Put a final "disclaimer" generator that creates an appropriate cautionary paragraph for the front/back matter when expert review exists.

---

## 20) Next steps & recommended immediate deliverables

I appended the following actionable deliverables to the blueprint:

1. Copy‑paste prompts for every agent.
2. A runnable orchestration skeleton (Python) you can adapt.
3. Minimal Postgres schema and sample queries.
4. Human Review UI wireframe and REST endpoints.
5. Testing, monitoring plan, cost guidance, and expert review flow.

