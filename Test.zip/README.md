
# KDP Agent Pipeline (Scaffold)

This repository is a scaffold for an autonomous, agentic pipeline that creates ultra-specific nonfiction books for KDP.

## Requirements
- Python 3.10+
- An OpenAI API key (set `OPENAI_API_KEY`)
- A Google API key for Gemini (set `GOOGLE_API_KEY`)

Official docs:
- Gemini API quickstart: https://ai.google.dev/gemini-api/docs/quickstart. citeturn0search0
- OpenAI Python quickstart: https://platform.openai.com/docs/quickstart. citeturn0search1

## Quickstart
```bash
python scaffold_generator.py  # creates this project
cd kdp_agent_pipeline
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY=...  # or set in .env
export GOOGLE_API_KEY=...
python -m kdp.orchestrator.demo_run
```

## What's included
- `kdp/orchestrator.py`: central controller skeleton
- `kdp/agents/`: individual agent templates (idea, research, outline, draft, style, repetition, fact_check, editor, qa, publisher)
- `prompts/`: prompt templates
- `requirements.txt` and `.env.example`

This scaffold provides placeholders and example code. Replace placeholders with your API keys and tune prompts per your needs.
