
"""Orchestrator skeleton for the agentic pipeline.
Replace llm_call() with your provider integration (OpenAI or Gemini clients).
"""
import os
import json
import asyncio
from pathlib import Path
from typing import Dict, Any
from concurrent.futures import ThreadPoolExecutor

from kdp.llm_utils import llm_call
from kdp.config import PROMPTS_DIR
from kdp.agents import idea_agent, research_agent, title_agent, outline_agent, draft_agent, expansion_agent, style_agent, repetition_detector_agent, fact_checker_agent, editor_agent, assembler_agent, qa_agent, publishing_prep_agent

class Orchestrator:
    def __init__(self, backend: str = 'openai', model_map: Dict[str,str] = None):
        self.backend = backend
        self.model_map = model_map or {
            'idea': 'gemini-1.5-flash',
            'research': 'gemini-1.5-flash',
            'title': 'gpt-5',
            'outline': 'gpt-5',
            'draft': 'gpt-5',
            'expansion': 'gpt-5',
            'style': 'gpt-5',
            'repetition': 'gemini-1.5-flash',
            'fact_checker': 'gemini-1.5-flash',
            'editor': 'gpt-5',
            'assembler': 'gpt-5',
            'qa': 'gemini-1.5-flash',
            'publishing_prep': 'gpt-5'
        }
        self.state = {}

    async def run_idea(self, categories):
        ideas = await idea_agent.run(categories=categories, backend="openai" if "gpt" in self.model_map['idea'] else "gemini", model=self.model_map['idea'])
        self.state['ideas'] = ideas
        return ideas

    async def run_research(self, idea):
        research = await research_agent.run(idea=idea, backend="openai" if "gpt" in self.model_map['research'] else "gemini", model=self.model_map['research'])
        self.state['research'] = research
        return research

    async def run_title(self, idea, research):
        title_data = await title_agent.run(idea=idea, research=research, backend="openai" if "gpt" in self.model_map['title'] else "gemini", model=self.model_map['title'])
        self.state['title_data'] = title_data
        return title_data

    async def run_outline(self, title: str, target_words: int):
        outline = await outline_agent.run(title=title, target_total_words=target_words, backend="openai" if "gpt" in self.model_map['outline'] else "gemini", model=self.model_map['outline'])
        self.state['outline'] = outline
        return outline

    async def draft_single_chapter(self, chapter_spec: Dict[str, Any]):
        chapter_draft = await draft_agent.run(chapter_spec_json=json.dumps(chapter_spec), backend="openai" if "gpt" in self.model_map['draft'] else "gemini", model=self.model_map['draft'])
        return chapter_draft

    async def run_expansion(self, chapter_draft: str, research_notes: Dict[str, Any]):
        expanded_draft = await expansion_agent.run(chapter_draft=chapter_draft, research_notes=research_notes, backend="openai" if "gpt" in self.model_map['expansion'] else "gemini", model=self.model_map['expansion'])
        return expanded_draft

    async def run_style(self, chapter_text: str):
        styled_text = await style_agent.run(chapter_text=chapter_text, backend="openai" if "gpt" in self.model_map['style'] else "gemini", model=self.model_map['style'])
        return styled_text

    async def run_repetition_detector(self, manuscript: str):
        repetition_flags = await repetition_detector_agent.run(manuscript=manuscript, backend="openai" if "gpt" in self.model_map['repetition'] else "gemini", model=self.model_map['repetition'])
        return repetition_flags

    async def run_fact_checker(self, manuscript: str):
        fact_flags = await fact_checker_agent.run(manuscript=manuscript, backend="openai" if "gpt" in self.model_map['fact_checker'] else "gemini", model=self.model_map['fact_checker'])
        return fact_flags

    async def run_editor(self, manuscript: str):
        edited_manuscript = await editor_agent.run(manuscript=manuscript, backend="openai" if "gpt" in self.model_map['editor'] else "gemini", model=self.model_map['editor'])
        return edited_manuscript

    async def run_assembler(self, chapters: list):
        assembled_output = await assembler_agent.run(chapters=chapters, backend="openai" if "gpt" in self.model_map['assembler'] else "gemini", model=self.model_map['assembler'])
        return assembled_output

    async def run_qa(self, manuscript: str):
        qa_report = await qa_agent.run(manuscript_text=manuscript, backend="openai" if "gpt" in self.model_map['qa'] else "gemini", model=self.model_map['qa'])
        return qa_report

    async def run(self):
        # Phase 0 - Prototype: Idea -> Outline -> Single Chapter Draft -> Style -> QA
        print("Running Idea Agent...")
        ideas = await self.run_idea(['parenting', 'health'])
        if not ideas:
            print("Idea Agent returned no ideas. Exiting.")
            return
        chosen_idea = ideas[0] # Assuming the first idea is chosen for simplicity
        print(f"Chosen Idea: {chosen_idea.get('title', 'No Title Found')}")

        print("Running Research Agent...")
        research = await self.run_research(chosen_idea)
        print("Research completed.")

        print("Running Title & Positioning Agent...")
        title_data = await self.run_title(chosen_idea, research)
        final_title = title_data[0]['title'] # Assuming the first title option is chosen
        print(f"Final Title: {final_title}")

        print("Running Outline Agent...")
        outline = await self.run_outline(final_title, target_words=15000)
        print(f"Outline created with {len(outline)} chapters.")

        # For single-chapter demo, pick the first chapter
        if outline:
            first_chapter_spec = outline[0]
            print(f"Drafting Chapter 1: {first_chapter_spec['chapter_title']}...")
            chapter_draft = await self.draft_single_chapter(first_chapter_spec)
            print("Chapter 1 Drafted.")

            print("Running Expansion Agent on Chapter 1...")
            expanded_draft = await self.run_expansion(chapter_draft, research)
            print("Chapter 1 Expanded.")

            print("Running Style & Human-Voice Agent on Chapter 1...")
            styled_draft = await self.run_style(expanded_draft)
            print("Chapter 1 Styled.")

            print("Running Repetition Detector on Chapter 1...")
            repetition_flags = await self.run_repetition_detector(styled_draft)
            print(f"Repetition Flags: {repetition_flags}")

            print("Running Fact-Checker Agent on Chapter 1...")
            fact_flags = await self.run_fact_checker(styled_draft)
            print(f"Fact Flags: {fact_flags}")

            print("Running Editor Agent on Chapter 1...")
            edited_chapter = await self.run_editor(styled_draft)
            print("Chapter 1 Edited.")

            print("Running Assembler Agent...")
            assembled_manuscript = await self.run_assembler([edited_chapter])
            print("Manuscript Assembled.")

            print("Running QA Agent...")
            qa_report = await self.run_qa(assembled_manuscript['manuscript'])
            print(f"QA Report: {qa_report}")
            print("Running Publishing Prep Agent...")
            publishing_metadata = await self.run_publishing_prep(assembled_manuscript['manuscript'], title_data[0])
            print(f"Publishing Metadata: {publishing_metadata}")
            with open('publishing_metadata.json', 'w') as f:
                json.dump(publishing_metadata, f, indent=4)
        else:
            print("No outline generated, cannot proceed with drafting.")

    async def run_publishing_prep(self, final_manuscript: str, title_metadata: Dict[str, Any]):
        publishing_metadata = await publishing_prep_agent.run(final_manuscript=final_manuscript, title_metadata=title_metadata, backend="openai" if "gpt" in self.model_map['publishing_prep'] else "gemini", model=self.model_map['publishing_prep'])
        return publishing_metadata


# demo runner
if __name__ == '__main__':
    import asyncio
    orch = Orchestrator(backend=os.environ.get('KDP_BACKEND','openai'))
    asyncio.run(orch.run())
