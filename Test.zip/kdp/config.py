from pathlib import Path

PROMPTS_DIR = Path(__file__).parent.parent / 'prompts'