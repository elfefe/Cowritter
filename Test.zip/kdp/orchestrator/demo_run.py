
# demo_run.py -- small runnable demonstration
import asyncio
from ..main_orchestrator import Orchestrator

async def main():
    orch = Orchestrator(backend='openai')
    await orch.run()

if __name__ == '__main__':
    asyncio.run(main())
