from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'repetition_detector_prompt.txt'

async def run(manuscript: str, backend='openai', model='gpt-3.5'):
    prompt = PROMPT.read_text()
    out = await llm_call(prompt.replace('Analyze the manuscript', f'Analyze the following manuscript:\n{manuscript}'), backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}