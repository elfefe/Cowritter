from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'publishing_prep_prompt.txt'

async def run(final_manuscript: str, title_metadata: dict, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    input_data = f"final_manuscript: {final_manuscript}\ntitle_metadata: {json.dumps(title_metadata)}"
    out = await llm_call(prompt.replace('Create KDP metadata including:', f'Create KDP metadata including from the following:\n{input_data}'), backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}