# qa_agent.py -- runs simple QA checks
import json
from pathlib import Path
import textwrap
from ..config import PROMPTS_DIR
from ..llm_utils import llm_call

async def run(manuscript_text: str, backend='openai', model='gpt-3.5'):
    prompt_template = Path(PROMPTS_DIR / 'qa_prompt.txt').read_text()
    prompt = prompt_template.replace('Given the final manuscript and acceptance thresholds', f'Given the final manuscript:\n{manuscript_text[:4000]}')
    out = await llm_call(prompt, backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}
