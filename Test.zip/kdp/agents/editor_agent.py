from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'editor_prompt.txt'

async def run(manuscript: str, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    out = await llm_call(prompt.replace('Edit the manuscript', f'Edit the following manuscript:\n{manuscript}'), backend=backend, model=model)
    # The editor agent is expected to return markdown and a JSON log.
    # For now, we'll just return the raw output and let the orchestrator handle parsing.
    return out