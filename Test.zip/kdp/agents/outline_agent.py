from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'outline_prompt.txt'

async def run(title: str, target_total_words: int, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    prompt = prompt.replace('<TITLE>', title).replace('<N>', str(target_total_words))
    out = await llm_call(prompt, backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}