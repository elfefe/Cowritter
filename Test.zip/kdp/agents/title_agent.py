from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'title_agent_prompt.txt'

async def run(idea: dict, research: dict, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    # For now, we'll just pass the idea and research as a combined string.
    # In a more sophisticated implementation, we'd format this more carefully.
    input_data = f"Idea: {json.dumps(idea)}\nResearch: {json.dumps(research)}"
    out = await llm_call(prompt.replace('From research notes', input_data), backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}