from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'assembler_prompt.txt'

async def run(chapters: list, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    # For now, we'll just pass the chapters as a combined string.
    # In a more sophisticated implementation, we'd format this more carefully.
    chapters_content = "\n\n".join([f"## Chapter {i+1}\n{chapter}" for i, chapter in enumerate(chapters)])
    out = await llm_call(prompt.replace('Merge all chapters', f'Merge the following chapters:\n{chapters_content}'), backend=backend, model=model)
    try:
        parsed_output = json.loads(out)
        # Ensure the output has the expected 'manuscript' key
        if 'manuscript' not in parsed_output:
            raise ValueError("Assembler Agent output missing 'manuscript' key.")
        return parsed_output
    except json.JSONDecodeError:
        return {'raw': out, 'error': 'Invalid JSON from Assembler Agent'}
    except ValueError as e:
        return {'raw': out, 'error': str(e)}