from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'research_prompt.txt'

async def run(idea: dict, backend='openai', model='gpt-3.5'):
    prompt = PROMPT.read_text()
    out = await llm_call(prompt.replace('<TITLE>', idea['title']), backend=backend, model=model)
    try:
        return json.loads(out)
    except Exception:
        return {'raw': out}