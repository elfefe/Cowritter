# style_agent.py -- humanizing editor stub
from pathlib import Path
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

async def run(chapter_text: str, backend='openai', model='gpt-4'):
    prompt_template = Path(PROMPTS_DIR / 'style_prompt.txt').read_text()
    prompt = prompt_template.replace('[chapter_text]', chapter_text)
    out = await llm_call(prompt, backend=backend, model=model)
    # The style agent is expected to return JSON and rewritten markdown.
    # For now, we'll just return the raw output and let the orchestrator handle parsing.
    return out
