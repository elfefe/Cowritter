
# idea_agent.py -- simple wrapper for the Idea Agent prompt
from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = PROMPTS_DIR / 'idea_prompt.txt'

async def run(categories: list, backend='openai', model='gpt-3.5'):
    prompt = PROMPT.read_text()
    out = await llm_call(prompt.replace('<CATEGORIES>', ','.join(categories)), backend=backend, model=model)
    # Extract JSON from markdown code block if present
    if out.strip().startswith("```json"):
        out = out.strip()[len("```json"):].strip()
        if out.endswith("```"):
            out = out[:-len("```")].strip()
    try:
        parsed_output = json.loads(out)
        if isinstance(parsed_output, list):
            return parsed_output
        else:
            # If it's a dictionary, wrap it in a list
            return [parsed_output]
    except json.JSONDecodeError:
        print(f"Warning: Idea Agent received non-JSON response: {out}")
        return [] # Return an empty list if JSON parsing fails
    except Exception as e:
        print(f"An unexpected error occurred in Idea Agent: {e}")
        return []
