from pathlib import Path
import json
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

PROMPT = Path(__file__).resolve().parent.parent.parent / 'prompts' / 'expansion_prompt.txt'

async def run(chapter_draft: str, research_notes: dict, backend='openai', model='gpt-4'):
    prompt = PROMPT.read_text()
    input_data = f"chapter_draft: {chapter_draft}\nresearch_notes: {json.dumps(research_notes)}"
    out = await llm_call(prompt.replace('[chapter_draft] and [research_notes]', input_data), backend=backend, model=model)
    return out