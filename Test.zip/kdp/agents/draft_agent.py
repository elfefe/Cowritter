# draft_agent.py -- produces a chapter draft given a chapter spec
import json
from pathlib import Path
from ..llm_utils import llm_call
from ..config import PROMPTS_DIR

async def run(chapter_spec_json: str, backend='openai', model='gpt-4'):
    prompt_template = Path(PROMPTS_DIR / 'draft_prompt.txt').read_text()
    # Assuming chapter_spec_json contains 'chapter_title', 'chapter_goal', 'subheadings'
    chapter_spec = json.loads(chapter_spec_json)
    prompt = prompt_template.replace('<NUM>', str(chapter_spec.get('chapter_number', 'X')))
    prompt = prompt.replace('[chapter title]', chapter_spec.get('chapter_title', ''))
    prompt = prompt.replace('[300-word goal]', chapter_spec.get('chapter_goal', ''))
    prompt = prompt.replace('[list]', '\n'.join(chapter_spec.get('subheadings', [])))
    prompt = prompt.replace('<target_words>', str(chapter_spec.get('target_word_count', 1400)))
    return await llm_call(prompt, backend=backend, model=model)
